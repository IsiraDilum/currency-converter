


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.sql.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.json.JSONException;
import org.json.JSONObject;
import javax.swing.*;
import java.util.Iterator;
import java.awt.*;
import java.awt.event.*;
import javax.swing.border.*;


class Main{
    private final String apiurl="https://v6.exchangerate-api.com/v6/b1d3ff39d56f7c7c2e101dd5/latest/USD";
    private final String url = "jdbc:mysql://localhost:3306/exchange_rates";
    private final String username = "root";
    private final String password = "root";
    public String getApiurl(){
        return apiurl;
    }
    public String getUrl(){
        return url;
    }
    public String getUsername(){
        return username;
    }
    public String getPassword(){
        return password;
    }


}

class DatabaseUpdate {
    public static void main(String[] args) throws JSONException {
        Main main=new Main();
        String API_URL = main.getApiurl();

        // Fetch data from API
        String jsonData = fetchDataFromAPI(API_URL);

        if (jsonData != null) {
            JSONObject exchangeData = new JSONObject(jsonData);
            JSONObject conversionRates = exchangeData.getJSONObject("conversion_rates");
            String lastUpdateTime = exchangeData.getString("time_last_update_utc");

            // Database connection parameters


            try (Connection connection = DriverManager.getConnection(main.getUrl(),main.getUsername(), main.getPassword())) {
                // Format last update time
                String formattedLastUpdateTime = formatLastUpdateTime(lastUpdateTime);

                // Create a Statement object
                try (Statement statement = connection.createStatement()) {
                    // Loop and update database
                    Iterator keys = conversionRates.keys();
                    while (keys.hasNext()) {
                        String currency = keys.next().toString();
                        Object rateObj = conversionRates.get(currency);

                        double rate;
                        if (rateObj instanceof Double) {
                            rate = (Double) rateObj;
                        } else if (rateObj instanceof Integer) {
                            rate = ((Integer) rateObj).doubleValue();
                        } else {
                            System.err.println("Unexpected rate type for currency: " + currency);
                            continue;
                        }

                        // Update data in the database
                        String query4 = "UPDATE exchange_rate SET conversion_rate = '" + rate + "' WHERE currency_code = '" + currency + "'";
                        String query5 = "UPDATE exchange_rate SET last_update_time = '" + formattedLastUpdateTime + "' WHERE currency_code = '" + currency + "'";
                        statement.executeUpdate(query4);
                        statement.executeUpdate(query5);

                        // Output
                        System.out.println("Currency Name(Code): " + currency +
                                ", Conversion Rate: " + rate +
                                ", Last Update Time: " + lastUpdateTime + "\nSuccessfully Updated");
                    }
                    System.out.println("Exchange_rates Database Successfully Updated.");
                    System.out.println("""

                            Group Members
                            1) K.A.Isira Dilum (DSE-A-022) 😎👌
                            2) K.S.D.Sandeepa  (DSE 029)   😁👌\s""");
                    SwingUtilities.invokeLater(() -> {
                        CurrencyConverterGUI gui = new CurrencyConverterGUI();
                        gui.setVisible(true);
                    });

                } catch (SQLException e) {
                    e.printStackTrace();
                }

            } catch (SQLException e) {
                e.printStackTrace();
            }
        } else {
            System.err.println("Failed to fetch data from the API.");
        }
    }
    private static String fetchDataFromAPI(String apiUrl) {
        StringBuilder jsonData = new StringBuilder();
        try {
            URL url = new URL(apiUrl);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");
            connection.setRequestProperty("Content-Type", "application/json");

            BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            String line;
            while ((line = reader.readLine()) != null) {
                jsonData.append(line);
            }
            reader.close();
            connection.disconnect();
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
        return jsonData.toString();
    }

    private static String formatLastUpdateTime(String lastUpdateTime) {
        try {
            // Parse last update time string into a Date object
            SimpleDateFormat inputDateFormat = new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss Z");
            Date lastUpdateDate = inputDateFormat.parse(lastUpdateTime);

            // Format the Date object into MySQL datetime format
            SimpleDateFormat mysqlDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            return mysqlDateFormat.format(lastUpdateDate);
        } catch (ParseException e) {
            e.printStackTrace();
            return null;
        }
    }
}



class CurrencyConverterGUI extends JFrame  {
    private final JTextField amountField;
    private final JComboBox<String> fromCurrencyDropdown;
    private final JComboBox<String> fromCurrencyDropdowncripto;
    private final JComboBox<String> toCurrencyDropdown;
    private final JComboBox<String> toCurrencyDropdowncripto;
    private final JButton convertButton;
    private final JLabel resultLabel;
    private final JRadioButton normalCurrencyRadioButton;
    private final JRadioButton cryptoCurrencyRadioButton;
    private final ButtonGroup currencyTypeButtonGroup;

    public CurrencyConverterGUI() {
        JButton convertButton1;
        setTitle("Currency Converter");
        setSize(820, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null); // Use null layout to position components manually
        getContentPane().setBackground(new Color(173, 216, 230)); // Light blue color

        JLabel titleLabel = new JLabel("Currency Converter");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 30));
        titleLabel.setBounds(230, 20, 350, 30);
        add(titleLabel);

        // Radio buttons for selecting currency type
        normalCurrencyRadioButton = new JRadioButton("Normal Currency");
        normalCurrencyRadioButton.setFont(new Font("Arial", Font.PLAIN, 18));
        normalCurrencyRadioButton.setSelected(true); // Default selection
        normalCurrencyRadioButton.setBackground(new Color(50, 200, 200));
        normalCurrencyRadioButton.setBounds(200, 70, 180, 30);
        //normalCurrencyRadioButton = new RoundedButton( 20); // 20 is the corner radius
        add(normalCurrencyRadioButton);

        cryptoCurrencyRadioButton = new JRadioButton("Crypto Currency");
        cryptoCurrencyRadioButton.setFont(new Font("Arial", Font.PLAIN, 18));
        cryptoCurrencyRadioButton.setBackground(new Color(50, 200, 200));
        cryptoCurrencyRadioButton.setBounds(400, 70, 160, 30);
        //cryptoCurrencyRadioButton = new RoundedButton( 20); // 20 is the corner radius
        add(cryptoCurrencyRadioButton);

        currencyTypeButtonGroup = new ButtonGroup();
        currencyTypeButtonGroup.add(normalCurrencyRadioButton);
        currencyTypeButtonGroup.add(cryptoCurrencyRadioButton);

        // Event listener for currency type selection
        normalCurrencyRadioButton.addActionListener(e -> enableNormalCurrencyFields());

        cryptoCurrencyRadioButton.addActionListener(e -> enableCryptoCurrencyFields());

        JLabel amountLabel = new JLabel("Amount:");
        amountLabel.setFont(new Font("Arial", Font.PLAIN, 18));
        amountLabel.setBounds(50, 160, 80, 30);
        add(amountLabel);

        amountField = new RoundedTextField(" Enter amount", 20, 10); // 20 is the corner radius
        amountField.setBounds(140, 160, 150, 30);
        add(amountField);

        amountField.addFocusListener(new FocusListener() {
            @Override
            public void focusGained(FocusEvent e) {
                if (amountField.getText().equals(" Enter amount")) {
                    amountField.setText("  ");
                    amountField.setForeground(Color.BLACK);
                }
            }

            @Override
            public void focusLost(FocusEvent e) {
                if (amountField.getText().isEmpty()) {
                    amountField.setForeground(Color.GRAY);
                    amountField.setText(" Enter amount");

                }
            }
        });
        amountField.setForeground(Color.GRAY);
        amountField.setFont(new Font("Arial", Font.PLAIN, 15));



        JLabel fromLabel = new JLabel("From:");
        fromLabel.setFont(new Font("Arial", Font.PLAIN, 18));
        fromLabel.setBounds(50, 120, 80, 30);
        add(fromLabel);

        fromCurrencyDropdown = new JComboBox<>();
        fromCurrencyDropdown.setFont(new Font("Arial", Font.PLAIN, 17));
        fromCurrencyDropdown.setBounds(140, 120, 150, 30);
        add(fromCurrencyDropdown);

        fromCurrencyDropdowncripto = new JComboBox<>();
        fromCurrencyDropdowncripto.setBounds(140, 120, 150, 30);
        fromCurrencyDropdowncripto.setFont(new Font("Arial", Font.PLAIN, 17));
        fromCurrencyDropdowncripto.setVisible(false);
        add(fromCurrencyDropdowncripto);

        JLabel toLabel = new JLabel("To:");
        toLabel.setFont(new Font("Arial", Font.PLAIN, 18));
        toLabel.setBounds(50, 200, 80, 30);
        add(toLabel);

        toCurrencyDropdown = new JComboBox<>();
        toCurrencyDropdown.setFont(new Font("Arial", Font.PLAIN, 17));
        toCurrencyDropdown.setBounds(140, 200, 150, 30);
        add(toCurrencyDropdown);

        toCurrencyDropdowncripto = new JComboBox<>();
        toCurrencyDropdowncripto.setBounds(140, 200, 150, 30);
        toCurrencyDropdowncripto.setFont(new Font("Arial", Font.PLAIN, 17));
        toCurrencyDropdowncripto.setVisible(false);
        add(toCurrencyDropdowncripto);

        convertButton1 = new RoundedButton("Convert", 20);
        convertButton = convertButton1;
        convertButton.setBounds(320, 300, 115, 48);
        convertButton.setFont(new Font("Arial", Font.PLAIN, 17));
        convertButton.setBackground(new Color(0, 123, 255));
        convertButton.setForeground(Color.WHITE);
        add(convertButton);

        resultLabel = new JLabel();
        resultLabel.setFont(new Font("Arial", Font.PLAIN, 18));
        resultLabel.setBounds(280, 245, 400, 30);
        add(resultLabel);

        RoundedOutputPanel outputPanel = new RoundedOutputPanel(20); // 20 is the corner radius
        outputPanel.setLayout(null);
        outputPanel.setBounds(50, 240, 720, 41);
        add(outputPanel);

        convertButton.addActionListener(e -> convertCurrency());

        populateCurrencyDropdowns();
    }

    // Method to enable fields for normal currency selection
    private void enableNormalCurrencyFields() {
        fromCurrencyDropdown.setVisible(true);
        toCurrencyDropdown.setVisible(true);
        fromCurrencyDropdowncripto.setVisible(false);
        toCurrencyDropdowncripto.setVisible(false);
    }

    // Method to enable fields for crypto currency selection
    private void enableCryptoCurrencyFields() {
        fromCurrencyDropdown.setVisible(false);
        toCurrencyDropdown.setVisible(false);
        fromCurrencyDropdowncripto.setVisible(true);
        toCurrencyDropdowncripto.setVisible(true);
    }

    private void populateCurrencyDropdowns() {
        try {
            String url = "jdbc:mysql://localhost:3306/exchange_rates";
            String user = "root";
            String password = "root";
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection connection = DriverManager.getConnection(url, user, password);
            Statement statement = connection.createStatement();

            String query = "SELECT currency_code FROM exchange_rate";
            ResultSet resultSet = statement.executeQuery(query);
            while (resultSet.next()) {
                String currencyID = resultSet.getString(1);
                fromCurrencyDropdown.addItem(currencyID);
                toCurrencyDropdown.addItem(currencyID);
            }
            String query0 = "SELECT currency_code FROM cripto_exchange_rate";
            ResultSet resultSet1 = statement.executeQuery(query0);
            while (resultSet1.next()) {
                String currencyID1 = resultSet1.getString(1);
                fromCurrencyDropdowncripto.addItem(currencyID1);
                toCurrencyDropdowncripto.addItem(currencyID1);
            }
            connection.close();
        } catch (Exception ex) {
            resultLabel.setText("Error: " + ex.getMessage());
        }
    }

    private void convertCurrency() {
        try {
            double amount = Double.parseDouble(amountField.getText());
            String fromCurrency;
            String toCurrency;
            double fromCurrencyValue;
            double toCurrencyValue;

            if (normalCurrencyRadioButton.isSelected()) {
                fromCurrency = (String) fromCurrencyDropdown.getSelectedItem();
                toCurrency = (String) toCurrencyDropdown.getSelectedItem();
            } else {
                fromCurrency = (String) fromCurrencyDropdowncripto.getSelectedItem();
                toCurrency = (String) toCurrencyDropdowncripto.getSelectedItem();
            }

            String url = "jdbc:mysql://localhost:3306/exchange_rates";
            String user = "root";
            String password = "root";
            Class.forName("com.mysql.cj.jdbc.Driver");
            try (Connection connection = DriverManager.getConnection(url, user, password)) {
                // Retrieve conversion rates for selected currencies
                try (Statement statement1 = connection.createStatement()) {
                    String query1;
                    if (normalCurrencyRadioButton.isSelected()) {
                        query1 = "SELECT conversion_rate FROM exchange_rate WHERE currency_code = '" + fromCurrency + "'";
                    } else {
                        query1 = "SELECT conversion_rate FROM cripto_exchange_rate WHERE currency_code = '" + fromCurrency + "'";
                    }
                    ResultSet resultSet1 = statement1.executeQuery(query1);
                    if (resultSet1.next()) {
                        fromCurrencyValue = resultSet1.getDouble("conversion_rate");
                    } else {
                        resultLabel.setText("Currency not found.");
                        return;
                    }
                }

                try (Statement statement2 = connection.createStatement()) {
                    String query2;
                    if (normalCurrencyRadioButton.isSelected()) {
                        query2 = "SELECT conversion_rate FROM exchange_rate WHERE currency_code = '" + toCurrency + "'";
                    } else {
                        query2 = "SELECT conversion_rate FROM cripto_exchange_rate WHERE currency_code = '" + toCurrency + "'";
                    }
                    ResultSet resultSet2 = statement2.executeQuery(query2);
                    if (resultSet2.next()) {
                        toCurrencyValue = resultSet2.getDouble("conversion_rate");
                    } else {
                        resultLabel.setText("Currency not found.");
                        return;
                    }
                }
            }

            double convertedAmount = amount /toCurrencyValue * fromCurrencyValue ;
            resultLabel.setText(String.format("%.2f %s = %.2f %s", amount, fromCurrency, convertedAmount, toCurrency));
        } catch (Exception ex) {
            resultLabel.setText("Error: " + ex.getMessage());
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            CurrencyConverterGUI gui = new CurrencyConverterGUI();
            gui.setVisible(true);
        });
    }
}
class RoundedButton extends JButton {
    private final int cornerRadius;

    public RoundedButton(String text, int cornerRadius) {
        super(text);
        this.cornerRadius = cornerRadius;
        setOpaque(false);
    }
    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        // Paint the background
        g2.setColor(getBackground());
        g2.fillRoundRect(0, 0, getWidth(), getHeight(), cornerRadius, cornerRadius);

        // Paint the text
        super.paintComponent(g2);

        g2.dispose();
    }

    @Override
    protected void paintBorder(Graphics g) {
        // No border needed
    }
}

class RoundedBorder extends AbstractBorder {
    private final int radius;

    public RoundedBorder(int radius) {
        this.radius = radius;
    }

    @Override
    public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setColor(c.getForeground());
        g2.drawRoundRect(x, y, width - 1, height - 1, radius, radius);
        g2.dispose();
    }
}

class RoundedTextField extends JTextField {
    private final int cornerRadius;

    public RoundedTextField(String text, int columns, int cornerRadius) {
        super(text, columns);
        this.cornerRadius = cornerRadius;
        setOpaque(false);
        setBorder(new RoundedBorder(cornerRadius));
    }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        // Paint the background
        g2.setColor(getBackground());
        g2.fillRoundRect(0, 0, getWidth(), getHeight(), cornerRadius, cornerRadius);

        // Paint the text
        super.paintComponent(g2);

        g2.dispose();
    }
}
class RoundedOutputPanel extends JPanel {
    private final int cornerRadius;

    public RoundedOutputPanel(int cornerRadius) {
        super();
        this.cornerRadius = cornerRadius;
        setOpaque(false);
    }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        // Paint the background
        g2.setColor(getBackground());
        g2.fillRoundRect(0, 0, getWidth(), getHeight(), cornerRadius, cornerRadius);

        // Paint the text
        super.paintComponent(g2);
        g2.dispose();
    }
}
