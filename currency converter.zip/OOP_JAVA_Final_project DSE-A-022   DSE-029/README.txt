                                        --------------------------- README_FILE ----------------------------

                                       \\\\\\\\  Readme File for Currency Converter programs in JAVA  ////////

(#) Overview

This currency converter app allows users to convert the value of one currency to another currency.Users are given the opportunity to choose the type of currency. Here the user is given the opportunity to choose Nomale currency or crypto currency and the user enters the currency unit and Amount and selects the currency unit to be converted and clicks the convert button to convert and get the value. It utilizes exchange rate data obtained from an external API to perform conversions accurately. 


(#) Features

- Currency Conversion     : Users can convert between various normal currencies and cryptocurrencies.

- User-Friendly Interface : The GUI provides an intuitive interface for users to input the amount and select currencies for conversion.

- Real-Time Data          : Exchange rates are fetched from a reliable API, ensuring that conversions are based on the latest market rates.

- Error Handling          : The application includes error handling mechanisms to address issues like invalid input and connection failures gracefully.


(#) Getting Started 

 To run the Currency Converter Application, follow these steps:

                    ----------  App to be installed ---------

 1) MySQL Workbench and Intellij IDEA must be installed to run this currency converter application.

                    ----------  IMPORT DATABASE  ---------

2) First, create a database called "exchange_rates" in MySQL Workbench. Then go to Server < Data Import in MySQL Workbench, select Import from Self Contained file and select the file path, and select "exchange_rates" Database in the DATABASE file where this README file is located.  After that select the "exchange_rates" Schema previously created in the Default Target Schema in the Default Schema to be Imported to section and click Start Import.

                   -----------  IMPORT PROJECT  ----------

3) Then open Intellij IDEA and select the "Final Project JAVA Code" project located at the same location as this README file through open new project.

                    -----------  RUN THE CODE  ---------

4)Go to Final Project JAVA Code < src < CurrencyConverterGUI Class and run the class



(#)  challenges faced & solutions 
    
    1)challenges - There are problems in creating the GUI interface
      solutions  - read the swing librarY 

    2)challenges - find api key 
      solutions  - use "https://v6.exchangerate-api.com" web site

    3)challenges - connect MySQL Workbench between Intellij IDEA
      solutions  - Use "mysql-connector-java-8.0.28" Library

    4)Challenge - Retrieving Data from API
      solution: Implemented a method (fetchDataFromAPI) to fetch JSON data from the API using HttpURLConnection.

    5)Challenge: Database Integration
      solution: Established database connectivity using JDBC, ensuring proper handling of SQL queries and result sets.

